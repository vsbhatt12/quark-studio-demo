import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-card-listing',
  templateUrl: './card-listing.component.html',
  styleUrls: ['./card-listing.component.css']
})
export class CardListingComponent implements OnInit {

  listOfTasks = [];
  allTaskDetails = [];
  todoTasks = [];
  inProgressTask = [];
  doneTask = [];
  searchText = '';

  constructor() { }

  ngOnInit() {
    if (localStorage.getItem('listOfTasks')) {
      this.listOfTasks = JSON.parse(localStorage.getItem('listOfTasks'));
      this.allTaskDetails = JSON.parse(localStorage.getItem('listOfTasks'));
    }
    this.filterTasks();
  }


  filterTasks() {
    this.todoTasks = [];
    this.inProgressTask = [];
    this.doneTask = [];
    this.listOfTasks.forEach(task => {
      switch (task.taskStatus) {
        case 1:
          this.todoTasks.push(task);
          break;
        case 2:
          this.inProgressTask.push(task);
          break;
        case 3:
          this.doneTask.push(task);
          break;
      }
    });
  }

  changeStatus(taskStatus, taskDetail) {
    this.listOfTasks.forEach(task => {
      if (task.task === taskDetail) {
        task.taskStatus = +taskStatus;
      }
    });
    this.filterTasks();
    this.allTaskDetails = this.listOfTasks;
    localStorage.setItem('listOfTasks', JSON.stringify(this.listOfTasks));
  }

  search() {
    this.listOfTasks = [];
    this.allTaskDetails.forEach(task => {
      if (task.task.toLowerCase().includes(this.searchText.toLowerCase().trim()) || task.assignee.toLowerCase().includes(this.searchText.toLowerCase().trim())) {
        this.listOfTasks.push(task);
      }
    });
    this.filterTasks();
  }
  clear() {
    this.searchText = '';
    this.listOfTasks = this.allTaskDetails;
    this.filterTasks();
  }

  deleteTask(task) {
    this.listOfTasks = this.listOfTasks.filter(function (obj) {
      return obj.task !== task;
    });
    this.allTaskDetails = this.listOfTasks;
    this.filterTasks();
    localStorage.setItem('listOfTasks', JSON.stringify(this.listOfTasks));
  }
}
