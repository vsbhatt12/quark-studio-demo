import { Component, OnInit, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-todo-form',
  templateUrl: './todo-form.component.html',
  styleUrls: ['./todo-form.component.css']
})
export class TodoFormComponent implements OnInit {

  task: string = '';
  assignee: string = '';
  taskStatus: number = 0;
  listOfTasks = [];
  @Output() viewListRedirectEmit = new EventEmitter()
  constructor() { }

  ngOnInit() {
    if (localStorage.getItem('listOfTasks')) {
      this.listOfTasks = JSON.parse(localStorage.getItem('listOfTasks'));
    }
  }

  onSubmit() {
    this.listOfTasks.push({
      task: this.task,
      assignee: this.assignee,
      taskStatus: +this.taskStatus
    });
    localStorage.setItem('listOfTasks', JSON.stringify(this.listOfTasks));
    this.task = '';
    this.assignee = '';
    this.taskStatus = 0;

  }
  redirectToViewList() {
    this.viewListRedirectEmit.emit();
  }
}
